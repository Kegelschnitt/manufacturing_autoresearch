class LessonMemory:
    def __init__(self):
        self.lessons = {}

    def add_lesson(self, lesson_id, data):
        self.lessons[lesson_id] = data

    def get_lessons(self):
        return self.lessons
