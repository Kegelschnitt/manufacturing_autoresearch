class LessonStats:
    def __init__(self):
        self.usage = {}

    def record_usage(self, lesson_id):
        self.usage[lesson_id] = self.usage.get(lesson_id, 0) + 1

    def get_stats(self):
        return self.usage
